/*
Copyright (c) 2017, Intel Corporation

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "opencv2/objdetect.hpp"
#include "opencv2/videoio.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

#include <librealsense/rs.hpp>

#include <gtk/gtk.h>
#include <glib.h>

#include <iostream>
#include <stdio.h>
#include <thread>
#include <chrono>
#include <unistd.h>
#include <atomic>
#include <random>


using namespace std;
using namespace cv;

string RESOURCE_PATH = "/usr/share/rps-demo/";
string test;
int startPressed = 0;

const char* getResource(string postPath){
  test = RESOURCE_PATH + postPath;
  return test.c_str();
}

//Cascade classifier global variables (replace these with your own if you want to use your own classifiers)
String rock_cascade_name = getResource("resources/classifiers/rock_cascade.xml");
String paper_cascade_name = getResource("resources/classifiers/paper_cascade.xml");
String scissors_cascade_name = getResource("resources/classifiers/scissors_cascade.xml");
CascadeClassifier rock_cascade;
CascadeClassifier paper_cascade;
CascadeClassifier scissors_cascade;

//Helper variables for multi-threading
atomic<bool> frameFeatureDetected(false);
atomic<bool> quitThreads(false);
bool startClassifying = false;

// Strings used by the game
String rock = "Rock";
String paper = "Paper";
String scissors = "Scissors";
String unknown = "Unknown";

bool rockNotPrinted = true;
bool paperNotPrinted = true;
bool scissorsNotPrinted = true;
bool notClassified = true;
bool playPressed = false;
float timeElapsed = 0;
float startTime = 0;

//Game logic variables
enum Condition{tie,computerwin,playerwin};
int playerScore;
int computerScore;
String playerChoise = unknown;
String computerChoise = unknown;

//Vector of classified frames
vector<String> classificationList;

//Create lists of different GUI objects so we can transition between them
vector<GObject*> objectListMenu;
//vector<GObject*> objectListSettings;
vector<GObject*> objectListStart;

//GUI global variables
Mat frame;
GObject *cameraDrawArea;
GObject *labelScorePlayer;
GObject *labelScoreComputer;
GObject *imageRockText;
GObject *imagePaperText;
GObject *imageScissorsText;
GObject *imageYouWinText;
GObject *imageYouLoseText;
GObject *imageTieText;

String window_name = "Rock Paper Scissors!";

//Init random
random_device rd;
mt19937 rng(rd());
uniform_int_distribution<int> dis(1,9999);



//Function prototypes
void detectFeature(string featureType, CascadeClassifier featureCascade, float scaleFactor, int minNeighbors );

string prediction(){
  int nRock = 0;
  int nPaper = 0;
  int nScissors = 0;

  //Find the amount of each classifications
  for ( auto &i : classificationList ) {
      if(i == rock) nRock++;
      if(i == paper) nPaper++;
      if(i == scissors) nScissors++;
  }

  //Then clear the classification list for next one
  classificationList.clear();


  //Return the most classified value or unknown if ambiguous
  if(nRock > nPaper && nRock > nScissors && nRock != 0) return rock;
  else if(nPaper > nRock && nPaper > nScissors && nPaper != 0) return paper;
  else if(nScissors > nRock && nScissors > nPaper && nScissors != 0) return scissors;
  else return unknown;

}

string getRandomChoise(){

    int n = dis(rng)%3;
    switch(n){
        case 0:
          return rock;
        case 1:
          return paper;
        case 2:
          return scissors;
        default:
          return unknown;
    }
}

void updateGUI(){
    //Draw camera
    gtk_widget_queue_draw(GTK_WIDGET(cameraDrawArea));

    //Draw player and computer score
    gtk_label_set_text(GTK_LABEL(labelScorePlayer), to_string(playerScore).c_str());
    gtk_label_set_text(GTK_LABEL(labelScoreComputer), to_string(computerScore).c_str());


}

void hide_image_texts(){
    gtk_widget_hide(GTK_WIDGET(imageRockText));
    gtk_widget_hide(GTK_WIDGET(imagePaperText));
    gtk_widget_hide(GTK_WIDGET(imageScissorsText));
    gtk_widget_hide(GTK_WIDGET(imageTieText));
    gtk_widget_hide(GTK_WIDGET(imageYouWinText));
    gtk_widget_hide(GTK_WIDGET(imageYouLoseText));
}

Condition determineWinner(string playerChoise, string computerChoise){

  if(playerChoise == computerChoise) return Condition::tie;
  else if(playerChoise == rock && computerChoise == paper) return Condition::computerwin;
  else if(playerChoise == paper && computerChoise == scissors) return Condition::computerwin;
  else if(playerChoise == scissors && computerChoise == rock) return Condition::computerwin;
  else return Condition::playerwin;
}

//Game logic is handled here
void gameLogicHandler(){
  float timeElapsedFromStart = timeElapsed - startTime;
  if(timeElapsedFromStart == 1 && rockNotPrinted){
    printf("Rock!!!\n");
    hide_image_texts();
    gtk_widget_show(GTK_WIDGET(imageRockText));
    rockNotPrinted = false;
  }
  if(timeElapsedFromStart == 2 && paperNotPrinted){
    printf("Paper!!!\n");
    hide_image_texts();
    gtk_widget_show(GTK_WIDGET(imagePaperText));
    paperNotPrinted = false;
  }
  if(timeElapsedFromStart == 3 && scissorsNotPrinted){
    printf("Scissors!!!\n");
    hide_image_texts();
    gtk_widget_show(GTK_WIDGET(imageScissorsText));
    scissorsNotPrinted = false;
    printf("Start Classifying!\n");
    startClassifying = true;
  }
  if(timeElapsedFromStart == 5 && notClassified){
    printf("Classification done!\n\n");
    hide_image_texts();
    startClassifying = false;
    playerChoise = prediction();
    notClassified = false;
    computerChoise = getRandomChoise();
    cout << "You chose: " << playerChoise << endl;
    cout << "The computer chose: " << computerChoise << endl;

    Condition endResult = determineWinner(playerChoise,computerChoise);
    if(endResult == Condition::tie){
      printf("It's a Tie!\n");
      gtk_widget_show(GTK_WIDGET(imageTieText));
    }
    else if (endResult == Condition::playerwin){
        printf("You win!\n");
        gtk_widget_show(GTK_WIDGET(imageYouWinText));
        playerScore++;
    }
    else{
        printf("You lose!\n");
        gtk_widget_show(GTK_WIDGET(imageYouLoseText));
        computerScore++;
    }


  }

  if(timeElapsedFromStart == 7){
      hide_image_texts();
      playPressed = false;
  }

}

//Function that updates the global time
gboolean updateTimer(gpointer data){

    timeElapsed += 1;
    return TRUE;
}

//This function starts the rock paper scissors game and initializes the camera feed and classification
static void startGame (GtkWidget *widget, gpointer data){
  g_print ("Starting Rock Paper Scissors!\n");

  //Show the game widgets and hide all other widgets
  for ( auto &i : objectListMenu ) {
    gtk_widget_hide(GTK_WIDGET(i));
  }

  for ( auto &i : objectListStart ) {
    gtk_widget_show(GTK_WIDGET(i));
  }

  //Init game logic variables
  playerScore = 0;
  computerScore = 0;

  //Capture video with librealsense camera
  rs::context ctx;
  rs::device * dev = ctx.get_device(0);

  dev->enable_stream(rs::stream::color, 640, 480, rs::format::bgr8, 30);

  //Start the camera stream
  dev->start();

  //Drop a few camera frames before starting the classification to stabilize the camera feed
  for(int i = 0; i < 30; i++)
     dev->wait_for_frames();

  //Creating OpenCV Matrix from a color image
  Mat color(Size(640, 480), CV_8UC3, (void*)dev->get_frame_data(rs::stream::color), Mat::AUTO_STEP);
  frame = color;

  //Load the cascades
  if( !rock_cascade.load( rock_cascade_name ) ){ printf("--(!)Error loading rock cascade\n"); return; };
  if( !paper_cascade.load( paper_cascade_name ) ){ printf("--(!)Error loading paper cascade\n"); return; };
  if( !scissors_cascade.load( scissors_cascade_name ) ){ printf("--(!)Error loading scissors cascade\n"); return; };

  //Initialize the classification threads
  //Change the numerical values to tweak the classification sensitivity
  thread tRock(detectFeature, rock,rock_cascade, 1.1, 500 );
  thread tPaper(detectFeature, paper,paper_cascade, 1.1, 500 );
  thread tScissors(detectFeature, scissors,scissors_cascade, 1.1, 530 );


  quitThreads = 0;

  // Update the timer every second
  gint timer_func = g_timeout_add(1000, updateTimer, cameraDrawArea );

  for(;;){
      dev->wait_for_frames();
      Mat color(Size(640, 480), CV_8UC3, (void*)dev->get_frame_data(rs::stream::color), Mat::AUTO_STEP);
      frameFeatureDetected = 0;

      frame = color;

      if(playPressed == true) gameLogicHandler();

      //Update updatable GUI widgets
      updateGUI();

      if(quitThreads == true)break;
      if(waitKey(1) == 27) break;

  }

  if(tRock.joinable())tRock.join();
  if(tPaper.joinable())tPaper.join();
  if(tScissors.joinable())tScissors.join();

  dev->stop();
  g_source_remove (timer_func);

}

//Show settings menu
/*
static void settings (GtkWidget *widget, gpointer data){
  g_print ("Settings\n");
  startPressed = 0;
}
*/

//Quit the program
static void quit (GtkWidget *widget, gpointer data){
  g_print("Exiting..\n");
  exit(0);
}

//This function stops the rock paper scissors game
static void stop (GtkWidget *widget, gpointer data){

  //Setting this to 1 forces the threads to join the main thread
  quitThreads = true;
  startClassifying = false;
  playPressed = false;

  //Show the menu widgets and hide all other widgets
  for ( auto &i : objectListMenu ) {
    gtk_widget_show(GTK_WIDGET(i));
  }

  for ( auto &i : objectListStart ) {
    gtk_widget_hide(GTK_WIDGET(i));
  }

  hide_image_texts();
}

//Starts a round of the game
static void play (GtkWidget *widget, gpointer data){

  hide_image_texts();

  //Set classfication booleans to true
  startClassifying = true;
  rockNotPrinted = true;
  paperNotPrinted = true;
  scissorsNotPrinted = true;
  notClassified = true;
  playPressed = true;
  startTime = timeElapsed;




}

//This function draws the camera feed
static void draw_callback (GtkWidget *widget, cairo_t *cr, gpointer data){

  Mat rgbframe;

  //Only try to draw the frame if it isn't empty
  if(!frame.empty()){

    //Change the frame channel format to gdk compatible RGB and set the frame to cairos pixbuffer which can then be drawn
    cvtColor(frame, rgbframe, CV_BGR2RGB);
    gdk_cairo_set_source_pixbuf (cr, gdk_pixbuf_new_from_data(rgbframe.data, GDK_COLORSPACE_RGB, false, 8, rgbframe.cols, rgbframe.rows, rgbframe.step, NULL , NULL), 0,0);

    //Draw the camera frame
    cairo_paint(cr);
    cairo_fill (cr);
  }
}

static void draw_background (GtkWidget *widget, cairo_t *cr, gpointer data){

  GdkPixbuf *pixbuf;
  GError *error = NULL;
  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/rps_background_futuristic.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }
  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_rock_text (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;
  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/rock_text.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_paper_text (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/paper_text.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_scissors_text (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/scissors_text.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_you_win_text (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/you_win_text.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_you_lose_text (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/you_lose_text.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_tie_text (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/tie_text.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_image_title (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/rock_paper_scissors_title_image_white.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_player_selection (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  if(playerChoise == scissors) pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imageScissors.png"), &error);
  else if(playerChoise == paper) pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imagePaper.png"), &error);
  else if(playerChoise == rock) pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imageRock.png"), &error);
  else pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imageUnknown.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_computer_selection (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  if(computerChoise == scissors) pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imageScissors.png"), &error);
  else if(computerChoise == paper) pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imagePaper.png"), &error);
  else if(computerChoise == rock) pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imageRock.png"), &error);
  else pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imageUnknown.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_computer_text (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imageComputerText.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}

static void draw_player_text (GtkWidget *widget, cairo_t *cr, gpointer data){
  GdkPixbuf *pixbuf;
  GError *error = NULL;

  pixbuf = gdk_pixbuf_new_from_file(getResource("resources/images/imagePlayerText.png"), &error);
  if(error){
    cout << "Error when opening image: " << error->message << endl;
    exit(-1);
  }

  gdk_cairo_set_source_pixbuf(cr, pixbuf, 0, 0);

  cairo_paint(cr);
  cairo_fill (cr);
}


//This function initializes all the widgets in the program
void init_widgets(){
  GtkBuilder *builder;
  GObject *window;

  //General widgets (always visible)
  GObject *imageBackground;
  GObject *imageTitle;

  //Main menu widgets
  GObject *buttonQuit;
  GObject *buttonStart;
  //GObject *buttonSettings;

  //Start game widgets
  GObject *buttonStop;
  GObject *buttonPlay;
  GObject *labelScore;
  GObject *labelPlayer;
  GObject *labelComputer;
  GObject *imagePlayerSelection;
  GObject *imageComputerSelection;
  GObject *imageComputerText;
  GObject *imagePlayerText;


  //Base window
  builder = gtk_builder_new ();
  gtk_builder_add_from_file (builder, getResource("resources/templates/rps_menu.glade"), NULL);

  window = gtk_builder_get_object (builder, "window1");
  g_signal_connect (window, "destroy", G_CALLBACK (quit), NULL);

  gtk_window_set_default_size(GTK_WINDOW(window), 1000, 0);

  //Menu
  buttonQuit = gtk_builder_get_object (builder, "buttonQuit");
  g_signal_connect (buttonQuit, "clicked", G_CALLBACK (quit), NULL);

  buttonStart = gtk_builder_get_object (builder, "buttonStart");
  g_signal_connect (buttonStart, "clicked", G_CALLBACK(startGame), NULL);

  //buttonSettings = gtk_builder_get_object (builder, "buttonSettings");
  //g_signal_connect (buttonSettings, "clicked", G_CALLBACK(settings), NULL);

  //Start Game
  buttonStop = gtk_builder_get_object (builder, "buttonStop");
  g_signal_connect (buttonStop, "clicked", G_CALLBACK(stop), NULL);

  cameraDrawArea = gtk_builder_get_object (builder, "cameraDrawArea");
  g_signal_connect (cameraDrawArea, "draw", G_CALLBACK (draw_callback), NULL);

  imageBackground = gtk_builder_get_object (builder, "imageBackground");
  g_signal_connect (imageBackground, "draw", G_CALLBACK (draw_background), NULL);

  imageTitle = gtk_builder_get_object (builder, "imageTitle");
  g_signal_connect (imageTitle, "draw", G_CALLBACK (draw_image_title), NULL);

  buttonPlay = gtk_builder_get_object (builder, "buttonPlay");
  g_signal_connect (buttonPlay, "clicked", G_CALLBACK(play), NULL);

  imageRockText = gtk_builder_get_object (builder, "imageRockText");
  g_signal_connect (imageRockText, "draw", G_CALLBACK (draw_rock_text), NULL);

  imagePaperText = gtk_builder_get_object (builder, "imagePaperText");
  g_signal_connect (imagePaperText, "draw", G_CALLBACK (draw_paper_text), NULL);

  imageScissorsText = gtk_builder_get_object (builder, "imageScissorsText");
  g_signal_connect (imageScissorsText, "draw", G_CALLBACK (draw_scissors_text), NULL);

  imageYouWinText = gtk_builder_get_object (builder, "imageYouWinText");
  g_signal_connect (imageYouWinText, "draw", G_CALLBACK (draw_you_win_text), NULL);

  imageYouLoseText = gtk_builder_get_object (builder, "imageYouLoseText");
  g_signal_connect (imageYouLoseText, "draw", G_CALLBACK (draw_you_lose_text), NULL);

  imageTieText = gtk_builder_get_object (builder, "imageTieText");
  g_signal_connect (imageTieText, "draw", G_CALLBACK (draw_tie_text), NULL);

  imagePlayerSelection = gtk_builder_get_object (builder, "imagePlayerSelection");
  g_signal_connect (imagePlayerSelection, "draw", G_CALLBACK (draw_player_selection), NULL);

  imageComputerSelection = gtk_builder_get_object (builder, "imageComputerSelection");
  g_signal_connect (imageComputerSelection, "draw", G_CALLBACK (draw_computer_selection), NULL);

  imagePlayerText = gtk_builder_get_object (builder, "imagePlayerText");
  g_signal_connect (imagePlayerText, "draw", G_CALLBACK (draw_player_text), NULL);

  imageComputerText = gtk_builder_get_object (builder, "imageComputerText");
  g_signal_connect (imageComputerText, "draw", G_CALLBACK (draw_computer_text), NULL);

  labelScore = gtk_builder_get_object (builder, "labelScore");
  labelScorePlayer = gtk_builder_get_object (builder, "labelScorePlayer");
  labelScoreComputer = gtk_builder_get_object (builder, "labelScoreComputer");
  labelPlayer = gtk_builder_get_object (builder, "labelPlayer");
  labelComputer = gtk_builder_get_object (builder, "labelComputer");


  //Add objects to their respective lists
  objectListMenu.push_back(buttonQuit);
  //objectListMenu.push_back(buttonSettings);
  objectListMenu.push_back(buttonStart);

  objectListStart.push_back(buttonStop);
  objectListStart.push_back(cameraDrawArea);
  objectListStart.push_back(buttonPlay);
  objectListStart.push_back(labelScore);
  objectListStart.push_back(labelScorePlayer);
  objectListStart.push_back(labelScoreComputer);
  objectListStart.push_back(labelPlayer);
  objectListStart.push_back(labelComputer);
  objectListStart.push_back(imageComputerSelection);
  objectListStart.push_back(imagePlayerSelection);
  objectListStart.push_back(imagePlayerText);
  objectListStart.push_back(imageComputerText);
}

//Main function
int main( int argc, char *argv[]){

    cout << "Path c_str: " << getResource("resources/images/rps_background_futuristic.png") << endl;
    cout << "Path string: " << test << endl;
    gtk_init (&argc, &argv);
    init_widgets();
    gtk_main();

    return 0;
}

//This function detects features such as (rock, paper or scissors) given the classifier and other necessary parameters
//It is designed for multi-threading (one thread for each feature but can also be used in single threading processes)
void detectFeature(string featureType, CascadeClassifier featureCascade, float scaleFactor, int minNeighbors ){

      //Only run if we don't have an exit call (quitThreads == 0)
      while(quitThreads == false){
          if(startClassifying == true){
              //Create a vector for detected features
              vector<Rect> features;

              //Turn the camera frame to gray scale before classification and qualize it for better contrast
              Mat frame_gray;
              cvtColor( frame, frame_gray, COLOR_BGR2GRAY );
              equalizeHist( frame_gray, frame_gray );


              //Detect the features and save them to the features vector
              featureCascade.detectMultiScale( frame_gray, features, scaleFactor, minNeighbors, 0|CASCADE_SCALE_IMAGE, Size(30, 30) );

              //If a feature was found print it
              if(features.size() > 0 && frameFeatureDetected == 0){
                  frameFeatureDetected = 1;
                  classificationList.push_back(featureType);
              }
          }
      }
}
